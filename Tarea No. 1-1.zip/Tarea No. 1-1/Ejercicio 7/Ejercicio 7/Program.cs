﻿using System;

namespace Ejercicio_7
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa en el cual se pueda calcular la superficie de un cuadrado conociendo el valor
            de un lado, sabiendo que: Superficie = (Lado * Lado).*/
            Console.Write("Digite el valor de un lado del cuadrado: ");
            int lado = int.Parse(Console.ReadLine());
            int superficie = lado * lado;
            Console.WriteLine($"La superficie del cuadrado es: {superficie}");

            Console.ReadKey();
        }
    }
}
