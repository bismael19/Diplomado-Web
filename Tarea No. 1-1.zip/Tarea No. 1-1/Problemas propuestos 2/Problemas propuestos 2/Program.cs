﻿using System;

namespace Problemas_propuestos_2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa que calcule la “Masa” de aire, pidiendo por teclado la presión, el
            volumen y la temperatura; teniendo en cuenta que la fórmula es: masa = (presión *
            volumen) / (0.37 * (temperatura + 460))*/

            Console.Write("Digite el valor de la presión: ");
            double presion = double.Parse(Console.ReadLine());
            Console.Write("Digite el valor del volumen: ");
            double volumen = double.Parse(Console.ReadLine());
            Console.Write("Digite el valor de la temperatura: ");
            double temperatura = double.Parse(Console.ReadLine());

            double masa = (presion * volumen) / (0.37 * (temperatura + 460));
            Console.WriteLine("La masa del aire es: {0}", masa);

            Console.ReadKey();
        }
    }
}
