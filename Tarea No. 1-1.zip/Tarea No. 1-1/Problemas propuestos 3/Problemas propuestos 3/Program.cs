﻿using System;

namespace Problemas_propuestos_3
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa que sea capaz de calcular el nuevo salario de un empleado si
            obtuvo un incremento del 40 % sobre su salario anterior.*/

            Console.Write("Digite su salario: ");
            double Salario = double.Parse(Console.ReadLine());
            double nSalario = Salario + (Salario * 0.4);
            Console.WriteLine($"Su nuevo salario es: {nSalario}");

            Console.ReadKey();
        }
    }
}
