﻿using System;

namespace Problemas_propuestos_5
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa que calcule el porcentaje de estudiantes hombres y el porcentaje
            de mujeres en el grupo de diplomado C#.*/

            Console.Write("Digite la cantidad de estudiantes femeninas: ");
            int F = int.Parse(Console.ReadLine());
            Console.Write("Digite la cantidad de estudiantes masculinos: ");
            int M = int.Parse(Console.ReadLine());

            double PF = (100 * F) / (F + M);
            double PM = (100 * M) / (F + M);
            Console.WriteLine("Porcentaje Femenino: {0}%", PF);
            Console.WriteLine("Porcentaje Masculino: {0}%", PM);

            Console.ReadLine();
        }
    }
}
