﻿using System;

namespace Problemas_propuestos_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa que pida por teclado el lado de un cuadrado, mostrar por pantalla
            el perímetro del mismo(El perímetro de un cuadrado se calcula multiplicando el valor del
            lado por cuatro).*/

            Console.Write("Digite el valor de un lado del cuadrado: ");
            int lado = int.Parse(Console.ReadLine());
            int perimetro = lado * 4;
            Console.WriteLine($"El perímetro del cuadrado es: {perimetro}");

            Console.ReadKey();
        }
    }
}
