﻿using System;

namespace Ejercicio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*El siguiente programa solicita dos números enteros por teclado e imprimir su suma y su
            multiplicación.*/

            Console.Write("Digita el valor1: ");
            int A = int.Parse(Console.ReadLine());
            Console.Write("Digita el valor2: ");
            int B = int.Parse(Console.ReadLine());

            int Suma = A + B;
            int Multi = A * B;

            Console.WriteLine("El resultado de la suma es: {0}", Suma);
            Console.WriteLine("El resultado de la multiplicacion es: {0}", Multi);

            Console.ReadKey();
        }
    }
}
