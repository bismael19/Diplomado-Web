﻿using System;

namespace Ejercicio_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Pedir por consola un nombre de persona y el nombre de una ciudad y mostrar por pantalla, el
            siguiente mensaje “Hola” < nombre >” bienvenido a” < ciudad >*/

            Console.Write("Digita tu nombre: ");
            string nombre = Console.ReadLine();
            Console.Write("Digita una ciudad: ");
            string ciudad = Console.ReadLine();

            Console.WriteLine($"Hola {nombre} bienbenido a {ciudad}");
            Console.ReadKey();
        }
    }
}
