﻿using System;

namespace Ejercicio_3
{
    class Program
    {
        static void Main(string[] args)
        {
            /*El siguiente Programa permite ingresar la cantidad de horas trabajadas por un Soporte Técnico
            y su pago por hora, mostrando seguidamente por pantalla el sueldo que se debe pagar.*/

            Console.Write("Digite las horas trabajadas: ");
            int HT = int.Parse(Console.ReadLine());
            Console.Write("Digite el costo por hora: ");
            double PH = double.Parse(Console.ReadLine());

            double Sueldo = PH * HT;
            Console.WriteLine($"Total a pagar: {Sueldo}");
            Console.ReadKey();
        }
    }
}
