﻿using System;

namespace Ejercicio_4
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa que pida por teclado el precio de un artículo y la cantidad a llevar por el
            cliente, además debe mostrar el total a pagar por pantalla.*/

            Console.Write("Digite la cantidad de productos a llevar: ");
            int CP = int.Parse(Console.ReadLine());
            Console.Write("Digite el precio del producto: ");
            double PP = double.Parse(Console.ReadLine());

            double TP = CP * PP;
            Console.WriteLine("Total a pagar: {0}", TP);
            Console.ReadKey();
        }
    }
}
