﻿using System;

namespace Problemas_propuestos_4
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa que solicite por teclado una cantidad en pesos, obtener la
            equivalencia en dólares, tomando en cuenta que la unidad cambiaria es un valor
            variable.*/
            Console.Write("Digite una cantidad en pesos dominicanos: ");
            double PD = double.Parse(Console.ReadLine());
            Console.Write("Digite el valor del dolar: ");
            double D = double.Parse(Console.ReadLine());
            
            D = PD / D;
            Console.WriteLine("Son {0} dolares....", D);
            Console.ReadKey();
        }
    }
}
