﻿using System;

namespace Ejercicio_6
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa que solicite por teclado una cantidad en pesos Dominicanos, obtener la
            equivalencia en dólares, tomando en cuenta que la unidad cambiaria es de 50 pesos por cada dólar.*/

            Console.Write("Digite una cantidad en pesos dominicanos: ");
            double PD = double.Parse(Console.ReadLine());

            double D = PD / 50;
            Console.WriteLine("Son {0} dolares....", D);
            Console.ReadKey();
        }
    }
}
