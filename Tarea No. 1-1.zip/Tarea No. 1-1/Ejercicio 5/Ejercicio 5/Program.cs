﻿using System;

namespace Ejercicio_5
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa en el cual se ingrese cuatro números, se debe calcular e informar:
                1 - La suma de los dos primeros números.
                2 - El producto del tercero y el cuarto número.
                3 - La División del primero y cuarto número.*/

            Console.Write("Digite 1er valor: ");            double P = double.Parse(Console.ReadLine());            Console.Write("Digite 2do valor: ");
            double S = double.Parse(Console.ReadLine());
            Console.Write("Digite 3er valor: ");            double T = double.Parse(Console.ReadLine());            Console.Write("Digite 4to valor: ");            double C = double.Parse(Console.ReadLine());            double Suma = P + S;            double Multi = T * C;            double Divi = P / C;            Console.WriteLine("El resultado de la suma es: {0}", Suma);            Console.WriteLine("El resultado de la multiplicacion es: {0}", Multi);            Console.WriteLine("El resultado de la division es: {0}", Divi);            Console.ReadKey();
        }
    }
}
