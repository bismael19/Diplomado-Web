﻿using System;

namespace Problemas_propuestos_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Desarrollar un programa que imprima los múltiplos de 3 del 1 al 200(Utilizar la
            Sentencia while)*/

            int N = 1;
            while (N <= 200)
            {
                if (N % 3 == 0)
                {
                    Console.WriteLine(N);
                }
                N++;
            }
            Console.ReadKey();
        }
    }
}
