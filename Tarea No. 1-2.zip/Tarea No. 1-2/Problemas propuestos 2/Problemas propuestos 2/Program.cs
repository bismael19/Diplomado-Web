﻿using System;

namespace Problemas_propuestos_2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Realizar un programa que dado un operario se conoce su sueldo y
            los años de antigüedad. Se pide confeccionar un programa que lea los datos de entrada
            e informe por pantalla:
            Si el sueldo es inferior a 500 y su antigüedad es igual o superior a 10 años, otorgarle un
            aumento del 20 %, mostrar el sueldo a pagar.
            Si el sueldo es inferior a 500 pero su antigüedad es menor a 10 años, otorgarle un
            aumento de 5 %.
            Si el sueldo es mayor o igual a 500 mostrar el sueldo en pantalla sin cambios.*/

            double nSueldo = 0, vSueldo = 0, aAnnos = 0;
            Console.Write("Digite el sueldo: ");
            vSueldo = double.Parse(Console.ReadLine());
            Console.Write("Digite años de antigüedad: ");
            aAnnos = double.Parse(Console.ReadLine());

            if ((vSueldo < 500) && (aAnnos >= 10))
            {
                nSueldo = (vSueldo * 0.2) + vSueldo;
                Console.WriteLine("Sueldo a pagar: {0}", nSueldo);
            }
            else if ((vSueldo < 500) && (aAnnos < 10))
            {
                nSueldo = (vSueldo * 0.05) + vSueldo;
                Console.WriteLine("Sueldo a pagar: {0}", nSueldo);
            }
            else if (vSueldo >= 500)
            {
                Console.WriteLine("Sueldo a pagar: {0}", vSueldo);
            }
            Console.ReadKey();
        }
    }
}
