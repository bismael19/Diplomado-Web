﻿using System;

namespace Ejercicio_4
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Realizar un programa que pida tres notas de un alumno, calcule el promedio e imprima lo
            siguiente:
            Si el promedio es > 10 mostrar "Aprobado".
            Si el promedio es > 7 y <= 10 mostrar "Desaprobado".
            Si el promedio es<7 mostrar "Reprobado".*/

            int Nota = 0, Promedio = 0;
            for (int i = 1; i <= 3; i++)
            {
                Console.Write("Digite nota{0}: ", i);
                Nota = int.Parse(Console.ReadLine());
                Promedio = Promedio + Nota;
            }
            Promedio = Promedio / 3;
            if (Promedio > 10)
            {
                Console.WriteLine("Aprobado");
            }
            else if ((Promedio > 7) && (Promedio <= 10))
            {
                Console.WriteLine("Desaprobado");
            }
            else if (Promedio < 7)
            {
                Console.WriteLine("Reprobado");
            }
            Console.ReadKey();
        }
    }
}
