﻿using System;

namespace Ejercicio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Realizar un programa que solicite ingresar dos números distintos y muestre por pantalla el mayor
            de ellos.*/

            Console.Write("Digite el 1er numero: ");
            double pNumero = double.Parse(Console.ReadLine());
            Console.Write("Digite el 2do numero: ");
            double sNumero = double.Parse(Console.ReadLine());

            if (pNumero > sNumero)
            {
                Console.WriteLine($"{pNumero} es mayor que {sNumero}");
            }
            else
            {
                Console.WriteLine($"{sNumero} es mayor que {pNumero}");
            }
            Console.ReadKey();
        }
    }
}
