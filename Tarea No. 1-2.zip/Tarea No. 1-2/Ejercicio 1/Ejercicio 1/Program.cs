﻿using System;

namespace Ejercicio_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Ingresar el sueldo de una persona, si supera los 3000 pesos mostrar un mensaje en pantalla
            indicando que debe abonar impuestos.*/
            Console.Write("Digite su sueldo: ");
            double sueldo = double.Parse(Console.ReadLine());

            if (sueldo > 3000)
            {
                Console.WriteLine("Esta persona debe abonar impuestos...");
            }
            Console.ReadKey();
        }
    }
}
