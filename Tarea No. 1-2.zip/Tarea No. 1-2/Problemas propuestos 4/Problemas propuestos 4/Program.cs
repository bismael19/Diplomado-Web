﻿using System;
using System.Collections.Generic;

namespace Problemas_propuestos_4
{
    class Program
    {
        static void Main(string[] args)
        {
            /*En un banco se procesan datos de las cuentas corrientes de sus clientes.De cada cuenta
            corriente se conoce: número de cuenta y saldo actual. El ingreso de datos debe finalizar
            al ingresar un valor negativo en el número de cuenta.
            Se pide realizar un programa que lea los datos de las cuentas corrientes e informe:
                        a) De cada cuenta: número de cuenta y estado de la cuenta según su saldo, sabiendo
                        que:
                        Estado de la cuenta-> 'Acreedor' si el saldo es > 0.
                                              'Deudor' si el saldo es<0.
                                              'Nulo' si el saldo es = 0.
            c) La suma total de los saldos acreedores.*/

            int eLista = 0;
            double nCuenta = 0, nSaldo = 0, sSaldo = 0;
            List<double> Cuenta = new List<double>();
            List<double> Saldo = new List<double>();
            List<string> Estado = new List<string>();

            do
            {
                Console.Write("Digite el numero de cuenta: ");
                nCuenta = double.Parse(Console.ReadLine());
                Console.Write("Digite el saldo de la cuenta: ");
                nSaldo = double.Parse(Console.ReadLine());
                Cuenta.Add(nCuenta);
                Saldo.Add(nSaldo);
                if (nSaldo > 0)
                {
                    Estado.Add("Acreedor");
                    sSaldo = sSaldo + nSaldo;
                }
                else if (nSaldo < 0)
                {
                    Estado.Add("Deudor");
                }
                else
                {
                    Estado.Add("Nulo");
                }
            }
            while (nCuenta >= 0);
            {
                eLista = Cuenta.Count;
                for (int i = 0; i < eLista; i++)
                {
                    Console.WriteLine($"Cuenta No.: {Cuenta[i]} **** Saldo: {Saldo[i]} **** Estado: {Estado[i]}");
                }
                Console.WriteLine("El saldo total de los Acreedores es de: {0}", sSaldo);
            }
            Console.ReadKey();
        }
    }
}
