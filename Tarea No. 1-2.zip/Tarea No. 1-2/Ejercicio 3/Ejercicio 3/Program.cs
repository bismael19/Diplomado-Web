﻿using System;

namespace Ejercicio_3
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Desarrollar un programa que permita ingresar n números enteros y luego nos imprima cuántos
            valores fueron pares y cuántos impares.*/

            int N = 0, Par = 0, Impar = 0, X = 0;
            Console.Write("Digite la cantidad de numeros a evaluar: ");
            N = int.Parse(Console.ReadLine());
            for (int i = 1; i <= N; i++)
            {
                Console.Write("Digite el valor{0}: ", i);
                X = int.Parse(Console.ReadLine());
                if (X % 2 == 0)
                {
                    Par++;
                }
                else
                {
                    Impar++;
                }
            }
            Console.WriteLine($"Hay {Par} pares y {Impar} impares...");
            Console.ReadKey();
        }
    }
}
