﻿using System;

namespace Problemas_propuestos_2
{
    class Plano
    {
        private int x, y;
        public void Cargar()
        {
            Console.Write("Digite el valor de X: ");
            x = int.Parse(Console.ReadLine());
            Console.Write("Digite el valor de Y: ");
            y = int.Parse(Console.ReadLine());
        }
        public void Imprimir()
        {
            if (x > 0 && y > 0)
            {
                Console.WriteLine("Pertenecen al 1er cuadrante...");
            }
            else if (x > 0 && y < 0)
            {
                Console.WriteLine("Pertenecen al 2do cuadrante...");
            }
            else if (x < 0 && y < 0)
            {
                Console.WriteLine("Pertenecen al 3er cuadrante...");
            }
            else
            {
                Console.WriteLine("Pertenecen al 4to cuadrante...");
            }
        }
        static void Main(string[] args)
        {
            /*Desarrollar un clase que represente un punto en el plano y tenga los siguientes metodos: 
            cargar los valores de x e y, imprimir en que cuadrante se encuentra dicho punto (concepto 
            matematico, primer cuadrante si x e y son positivas, si x<0 e y>0 segundo cuadrant, etc.)*/

            Plano pl = new Plano();
            pl.Cargar();
            pl.Imprimir();
            Console.ReadKey();
        }
    }
}
