﻿using System;

namespace Ejercicio_5
{
    class Cliente
    {
        private string nombre;
        private int monto;

        public Cliente(string nom)
        {
            nombre = nom;
            monto = 0;
        }
        public void Depositar(int m)
        {
            monto = monto + m;
        }
        public void Extraer(int m)
        {
            monto = monto - m;
        }
        public int Retornarmonto()
        {
            return monto;
        }
        public void Imprimir()
        {
            Console.WriteLine(nombre + " tiene depositado la suma de " + monto);
        }
        class Banco
        {
            private Cliente cliente1, cliente2, cliente3;
            public Banco()
            {
                cliente1 = new Cliente("Juan");
                cliente2 = new Cliente("Ana");
                cliente3 = new Cliente("Pedro");
            }
            public void Operar()
            {
                cliente1.Depositar(1000);
                cliente2.Depositar(150);
                cliente3.Depositar(200);
                cliente3.Extraer(150);
            }
            public void DepositosTotales()
            {
                int t = cliente1.Retornarmonto() + cliente2.Retornarmonto() + cliente3.Retornarmonto();
                Console.WriteLine("El total de dinero en el banco es: " + t);
                cliente1.Imprimir();
                cliente2.Imprimir();
                cliente3.Imprimir();
            }
        }
        static void Main(string[] args)
        {
            /*Un banco tiene 3 clientes que pueden hacer depositos y extracciones. Tmbien el banco
            requiere que al final del dia clacule la cnatidad de dinero que hay depositada.
            Creamos un proyecto llamado: Colaboracioncase y dentro del proyecto creamos dos clases
            llamdas: Cliente y Banco*/

            Banco banco1 = new Banco();
            banco1.Operar();
            banco1.DepositosTotales();
            Console.ReadKey();
        }
    }
}
