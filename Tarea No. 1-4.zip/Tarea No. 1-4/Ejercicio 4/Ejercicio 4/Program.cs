﻿using System;

namespace Ejercicio_4
{
    class Operaciones
    {
        private int valor1, valor2;
        public void Inicializar()
        {
            Console.Write("Digite el valor1: ");
            valor1 = int.Parse(Console.ReadLine());
            Console.Write("Digite el valor2: ");
            valor2 = int.Parse(Console.ReadLine());
        }
        public void Sumar()
        {
            int suma;
            suma = valor1 + valor2;
            Console.WriteLine($"{valor1} + {valor2} = {suma}");            
        }
        public void Restar()
        {
            int resta;
            resta = valor1 - valor2;
            Console.WriteLine($"{valor1} - {valor2} = {resta}");
        }
        public void Multiplicar()
        {
            int multiplicacion;
            multiplicacion = valor1 * valor2;
            Console.WriteLine($"{valor1} X {valor2} = {multiplicacion}");
        }
        public void Dividir()
        {
            int division;
            division = valor1 / valor2;
            Console.WriteLine($"{valor1} / {valor2} = {division}");
        }
        static void Main(string[] args)
        {
            /*implementar la clase operadores.Se deben implementar los dos valores enteros, calcular 
            su suma, rest, multiplicacion y division, cada un en un metodo, e imprimir dichos resultados*/

            Operaciones op = new Operaciones();
            op.Inicializar();
            op.Sumar();
            op.Restar();
            op.Multiplicar();
            op.Dividir();
            Console.ReadKey();
        }
    }
}
