﻿using System;

namespace Problemas_propuestos_3
{
    class Socio
    {
        private string nombre;
        private int antiguedad;
        public Socio (string nom)
        {
            nombre = nom;
            antiguedad = 0;
        }
        public void AnnoAntiguedad(int aa)
        {
            antiguedad = antiguedad + aa;
        }
        public int RetornarAnnoAntiguedad()
        {
            return antiguedad;
        }
        public string RetornarSocio()
        {
            return nombre;
        }
        class Club
        {
            private Socio socio1, socio2, socio3, socio4;
            public Club()
            {
                socio1 = new Socio("Juan");
                socio1.AnnoAntiguedad(5);
                socio2 = new Socio("Pablo");
                socio2.AnnoAntiguedad(7);
                socio3 = new Socio("Ana");
                socio3.AnnoAntiguedad(8);
                socio4 = new Socio("Rosa");
                socio4.AnnoAntiguedad(9);
            }
            public void SocioAntiguo()
            {
                if (socio1.RetornarAnnoAntiguedad() > socio2.RetornarAnnoAntiguedad()
                    && socio1.RetornarAnnoAntiguedad() > socio3.RetornarAnnoAntiguedad()
                    && socio1.RetornarAnnoAntiguedad() > socio4.RetornarAnnoAntiguedad())
                {
                    Console.WriteLine(socio1.RetornarSocio() + " es el socio mas antiguo con " + socio1.RetornarAnnoAntiguedad() + " años");
                }
                else if (socio2.RetornarAnnoAntiguedad() > socio1.RetornarAnnoAntiguedad()
                    && socio2.RetornarAnnoAntiguedad() > socio3.RetornarAnnoAntiguedad()
                    && socio2.RetornarAnnoAntiguedad() > socio4.RetornarAnnoAntiguedad())
                {
                    Console.WriteLine(socio2.RetornarSocio() + " es el socio mas antiguo con " + socio2.RetornarAnnoAntiguedad() + " años");
                }
                else if (socio3.RetornarAnnoAntiguedad() > socio1.RetornarAnnoAntiguedad()
                    && socio3.RetornarAnnoAntiguedad() > socio2.RetornarAnnoAntiguedad()
                    && socio3.RetornarAnnoAntiguedad() > socio4.RetornarAnnoAntiguedad())
                {
                    Console.WriteLine(socio3.RetornarSocio() + " es el socio mas antiguo con " + socio3.RetornarAnnoAntiguedad() + " años");
                }
                else
                {
                    Console.WriteLine(socio4.RetornarSocio() + " es el socio mas antiguo con " + socio4.RetornarAnnoAntiguedad() + " años");
                }
            }
        }
        static void Main(string[] args)
        {
            /*Plantear una clase Club y otra clase Socio. La clse Socio debe tener los siguientes 
            atributos privados: nombre y la antiguedad en el club (en años). En el constructor pedir 
            la carga del nombre y su antiguedad. La clase Club debe tener como atributos 3 objetos de 
            la clase Socio. Definir una responsabilidad para imprimir el nombre del socio con mayor 
            antiguedad en el club.*/

            Club c = new Club();
            c.SocioAntiguo();
            Console.ReadKey();
        }
    }
}
