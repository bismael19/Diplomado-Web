﻿using System;

namespace Ejercicio_1
{
    class Triangulo
    {
        private int lado1, lado2, lado3;
        public void Inicializar()
        {
            Console.Write("Digite lado1: ");
            lado1 = int.Parse(Console.ReadLine());
            Console.Write("Digite lado2: ");
            lado2 = int.Parse(Console.ReadLine());
            Console.Write("Digite lado3: ");
            lado3 = int.Parse(Console.ReadLine());
        }
        public void LadoMayor()
        {
            Console.Write("Lado mayor: ");
            if (lado1 > lado2 && lado1 > lado3)
            {
                Console.WriteLine(lado1);
            }
            else if (lado2 > lado1 && lado2 > lado3)
            {
                Console.WriteLine(lado2);
            }
            else
            {
                Console.WriteLine(lado3);
            }
        }
        public void EsEquilatero()
        {
            if (lado1 == lado2 && lado1 == lado3)
            {
                Console.WriteLine("Es un triangulo equilatero");
            }
            else
            {
                Console.WriteLine("No es un triangulo equilatero");
            }
        }
        static void Main(string[] args)
        {
            /*Desarrollar un programa con una llamada triangulo, que permita ingresar los lados de un 
            triangulo e implemente los siguientes metodos: inicializar los atributos, imprimir el valor 
            del lado mayor y otro metodo que muestre si es equilatero o no.*/
            Triangulo nTriangulo = new Triangulo();
            nTriangulo.Inicializar();
            nTriangulo.LadoMayor();
            nTriangulo.EsEquilatero();
            Console.ReadKey();
        }
    }
}
