﻿using System;

namespace Ejercicio_2
{
    class Persona
    {
        private string nombre;
        private int edad;
        public void Inicializar()
        {
            Console.Write("Digite su nombre: ");
            nombre = Console.ReadLine();
            Console.Write("Digite su edad: ");
            edad = int.Parse(Console.ReadLine());
        }
        public void Imprimir()
        {
            Console.WriteLine($"Su nombre es: {nombre}");
            Console.WriteLine($"Su edad es: {edad}");
        }
        public void MayorEdad()
        {
            if (edad >= 18)
            {
                Console.WriteLine("Es mayor de edad");
            }
            else
            {
                Console.WriteLine("Es menor de edad");
            }
        }
        static void Main(string[] args)
        {
            /*Realizar un programa que tenga una clase que permita ingresar el nombre y la edad de 
            la una persona. Mostrar los datos ingresados. imprimir un mensaje si es mayor de edad 
            (edad>=18)*/

            Persona pMayor = new Persona();
            pMayor.Inicializar();
            pMayor.Imprimir();
            pMayor.MayorEdad();
            Console.ReadKey();
        }
    }
}
