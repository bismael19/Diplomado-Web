﻿using System;

namespace Ejercicio_3
{
    class Cuadrado
    {
        private int lado;
        public void Inicializar()
        {
            Console.Write("Digite el valor del lado: ");
            lado = int.Parse(Console.ReadLine());
        }
        public void ImprimirPerimetro()
        {
            int perimetro;
            perimetro = lado * 4;
            Console.WriteLine("El perimetro es: " + perimetro);
        }
        public void ImprimirSuperficie()
        {
            int superficie;
            superficie = lado * lado;
            Console.WriteLine("La superficie es: " + superficie);
        }
        static void Main(string[] args)
        {
            /*desarrollar un program que tenga una clase que represente un cuadrado y tenga los 
            siguientes metodos: ingresar valor a su lado, imprimir su perimetro y su superficie.*/

            Cuadrado nCuadrado = new Cuadrado();
            nCuadrado.Inicializar();
            nCuadrado.ImprimirPerimetro();
            nCuadrado.ImprimirSuperficie();
            Console.ReadKey();
        }
    }
}
