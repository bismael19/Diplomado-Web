﻿using System;

namespace Problemas_propuestos_1
{
    class Empleado
    {
        private string nombre;
        private double sueldo;
        public void Carga()
        {
            Console.Write("Digite su nombre: ");
            nombre = Console.ReadLine();
            Console.Write("Digite su sueldo: ");
            sueldo = double.Parse(Console.ReadLine());
        }
        public void Imprimir()
        {
            Console.WriteLine("Su Nombre es: " + nombre);
            Console.WriteLine("Su sueldo es : " + sueldo);
        }
        public void Impuesto()
        {
            if (sueldo > 30000)
            {
                Console.WriteLine("Debe pagar Impuestos....");
            }
        }
        static void Main(string[] args)
        {
            /*Confeccionar una clase que represente un empleado. Definir como atributos su nombre y su
            sueldo. Confeccionar los metodos para la carga, otro para imprimir sus datos y y ultimo uno
            que imprima un mensaje si deb pagar impuestos (si el suledo supera a 30,000)*/

            Empleado em = new Empleado();
            em.Carga();
            em.Imprimir();
            em.Impuesto();
            Console.ReadKey();
        }
    }
}
