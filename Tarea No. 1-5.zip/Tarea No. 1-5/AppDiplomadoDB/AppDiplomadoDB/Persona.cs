﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppDiplomadoDB
{
    public class Persona
    {
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Cedula { get; set; }
        public string Direccion { get; set; }
    }
}
