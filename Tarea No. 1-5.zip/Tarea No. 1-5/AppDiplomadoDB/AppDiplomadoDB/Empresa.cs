﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppDiplomadoDB
{
    public class Empresa
    {
        public string Nombre { get; set; }
        public string RCN { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
    }
}
