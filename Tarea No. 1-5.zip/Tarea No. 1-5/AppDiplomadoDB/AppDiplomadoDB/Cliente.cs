﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppDiplomadoDB
{
    public class Cliente:Persona
    {
        public decimal LimiteCredito { get; set; }
    }
}
