﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppDiplomadoDB
{
    public class Empleado:Persona
    {
        public decimal Sueldo { get; set; }
        public DateTime Horario { get; set; }
        public string Puesto { get; set; }
        public string Seguro { get; set; }
    }
}
