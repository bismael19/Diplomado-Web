﻿using System;

namespace Ejercicio_de_codificacion_3._3
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa en C# que pida la edad de una persona y muestre en pantalla lo siguiente
            según criterio:*/            
            int Edad = 0;
            
            Console.WriteLine("Digita una edad: ");
            Edad = int.Parse(Console.ReadLine());

            if ((Edad >= 0) && (Edad <= 1))
            {
                Console.WriteLine("Bebé");
            }
            else if ((Edad >= 2) && (Edad <= 12))
            {
                Console.WriteLine("Niño");
            }
            else if ((Edad >= 13) && (Edad <= 17))
            {
                Console.WriteLine("Adolescente");
            }
            else if ((Edad >= 18) && (Edad <= 30))
            {
                Console.WriteLine("Joven");
            }
            else if ((Edad >= 31) && (Edad <= 64))
            {
                Console.WriteLine("Adulto");
            }
            else if ((Edad >= 65) && (Edad <= 120))
            {
                Console.WriteLine("Anciano");
            }
            else if ((Edad > 125) || (Edad < 0))
            {
                Console.WriteLine("Error");
            }

            Console.ReadKey();
        }
    }
}
