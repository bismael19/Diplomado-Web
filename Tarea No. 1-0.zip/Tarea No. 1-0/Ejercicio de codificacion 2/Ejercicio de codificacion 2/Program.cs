﻿using System;

namespace Ejercicio_de_codificacion_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("------------------> PROGRAM QUE SUMA DOS NUMEROS <------------------");
            Console.WriteLine("Ingrese el primer valor:");
            double valor1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingrese el segundo valor:");
            double valor2 = double.Parse(Console.ReadLine());
            double resultado = valor1 + valor2;
            Console.WriteLine("El resultado es {0}", resultado);

            Console.ReadKey();
        }
    }
}
