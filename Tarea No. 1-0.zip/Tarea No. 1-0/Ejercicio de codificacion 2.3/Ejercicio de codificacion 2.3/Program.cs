﻿using System;

namespace Ejercicio_de_codificacion_2._3
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa en C# que ingrese el nombre de un producto, el precio y la cantidad. El
            programa calculará el ITBIS que es del 18 %.Imprimir el sub total, el monto de itbis y el total a
            pagar.*/

            Console.WriteLine("Digite el producto:");
            string producto = Console.ReadLine();
            Console.WriteLine("Digite el precio:");
            double precio = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite la cantidad:");
            int cantidad = int.Parse(Console.ReadLine());

            double sub_total = precio * cantidad;
            double itbis = sub_total * 0.18;
            double total_pagar = sub_total + itbis;

            Console.WriteLine("");
            Console.WriteLine("Producto: {0} ----- Cantidad: {1}", producto, cantidad);
            Console.WriteLine("------------------- Sub Total: {0}", sub_total);
            Console.WriteLine("------------------- ITBIS 18.00%: {0}", itbis);
            Console.WriteLine("------------------- Total a Pagar: {0}", total_pagar);
        }
    }
}
