﻿using System;

namespace Ejercicio_de_codificacion_2._5
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escriba un programa que convierta de centímetros a pulgadas.Una pulgada es igual a 2.54
            centímetros.Los centímetros ingresan por teclado.*/

            Console.WriteLine("Digite los centimetros: ");
            double centimetro = double.Parse(Console.ReadLine());
            double pulgada = centimetro / 2.54;

            Console.WriteLine("Son {0} pulgadas", pulgada);
        }
    }
}
