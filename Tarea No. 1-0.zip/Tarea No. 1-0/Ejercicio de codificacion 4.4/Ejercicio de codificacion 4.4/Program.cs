﻿using System;

namespace Ejercicio_de_codificacion_4._4
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 12; i++)
            {
                int R = 4 * i;
                Console.WriteLine($"4 X {i} = {R}");
            }
            Console.ReadLine();
        }
    }
}
