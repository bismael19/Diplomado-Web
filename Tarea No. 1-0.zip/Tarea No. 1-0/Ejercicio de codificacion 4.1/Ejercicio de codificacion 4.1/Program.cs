﻿using System;

namespace Ejercicio_de_codificacion_4._1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa que muestre los números del 1 al 100.*/

            for (int i = 1; i <= 100; i++)            {
                Console.WriteLine(i);
            }            Console.ReadKey();
        }
    }
}
