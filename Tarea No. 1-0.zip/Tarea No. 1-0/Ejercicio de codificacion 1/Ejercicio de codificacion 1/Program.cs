﻿using System;

namespace Ejercicio_de_codificacion_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Crea una aplicación en C# que muestre información de una persona. La información a mostrar es:
            nombre, apellido, apodo, fecha nacimiento, teléfono, móvil, país, cuidad, dirección, lugar de
            trabajo, sueldo.*/

            Console.WriteLine("----------------->> INFORMACION PERSONAL <<-----------------");
            Console.WriteLine("Nombre: Bismael");
            Console.WriteLine("Apellido: Mateo Peña");
            Console.WriteLine("Apodo: Machine");
            Console.WriteLine("Fecha Nacimiento :17/12/1992");
            Console.WriteLine("Teléfono: 809-557-4759");
            Console.WriteLine("Móvil: 829-393-1992");
            Console.WriteLine("País: Republica Dominicana");
            Console.WriteLine("Ciudad: San Juan");
            Console.WriteLine("Dirección: Avenida Circumbalación Este...");
            Console.WriteLine("Lugar de Trabajo: Las Matas de Farfan");
            Console.WriteLine("Sueldo: $RD 30,000.00");

            Console.ReadKey();
        }
    }
}
