﻿using System;

namespace Ejercicio_de_codificacion_6._2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Crear una aplicación que calcule e imprima la sumatoria de los elementos de un vector.Los
            elementos ingresarán por teclado.*/
            int n = 0, suma = 0;
           
            Console.Write("Digite la cantidad de elementos del vector: ");
            int e = int.Parse(Console.ReadLine());

            int[] vector = new int[e];
            for (int i = 0; i < e; i++)
            {
                n++;
                Console.Write($"Digite el código del vector {n} de {e}: ");
                vector[i] = int.Parse(Console.ReadLine());
                suma = suma + vector[i];
            }
            Console.Write($"Resultado de la suma es: {suma}");
            Console.ReadKey();
        }
    }
}
