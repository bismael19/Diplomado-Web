﻿using System;

namespace Ejercicio_de_codificacion_2._1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escriba un programa que pida al usuario que escriba su nombre, y lo salude llamándolo por su
            nombre*/

            Console.WriteLine("Digita tu nombre:");
            string nombre = Console.ReadLine();
            Console.WriteLine("Hola! {0}", nombre);

            Console.ReadKey();
        }
    }
}
