﻿using System;

namespace Ejercicio_de_codificacion_4._2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Un programa que muestre los números del 100 al 105*/

            for (int i = 100; i <= 105; i++)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
