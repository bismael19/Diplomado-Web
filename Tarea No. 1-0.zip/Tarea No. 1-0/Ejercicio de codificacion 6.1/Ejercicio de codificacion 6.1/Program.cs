﻿using System;
using System.Collections.Generic;

namespace Ejercicio_de_codificacion_6._1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Crear una aplicación que cargue un vector de 5 códigos validos. Los códigos ingresaran por teclado.*/
            int n = 0;
            int[] vector = new int[5];

            for (int i = 0; i < 5; i++)
            {
                n++;
                Console.Write($"Digite el código del vector {n} de 5: ");
                vector[i] = int.Parse(Console.ReadLine());
            }
            Console.Write("El vector contiene los siguientes codigos: ");
            for (int j = 0; j < 5; j++)
            {
                Console.Write($"[{vector[j]}]");
            }

            Console.ReadKey();
        }
    }
}
