﻿using System;

namespace Ejercicio_de_codificacion_3._1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa que java que calcule sueldo bruto(SB), sueldo neto(SN) y descuento(DD).
            Las tarifas por horas(HT) y horas trabajadas(TH) ingresan por teclado.Si el sueldo bruto es mayor
            a 5,000.00 se descuenta un 10 %, de lo contrario se descuenta un 5 %.Imprimir sueldo bruto,
            descuento y sueldo neto.*/

            double SB = 0, DD = 0, SN = 0, HT = 0;
            string DT = null;
            int TH = 0;

            Console.WriteLine("Digite las tarifas por horas: ");
            HT = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite las horas trabajadas: ");
            TH = int.Parse(Console.ReadLine());

            SB = HT * TH;

            if (SB > 5000)
            {
                DD = SB * 0.1;
                SN = SB - DD;
                DT = "10%";
            }
            else
            {
                DD = SB * 0.05;
                SN = SB - DD; 
                DT = "5%";
            }

            Console.WriteLine("Su sueldo bruto es de: {0}", SB);
            Console.WriteLine("Tiene un descuento de un {0}: {1}", DT, DD);
            Console.WriteLine("Su sueldo neto es de: {0}", SN);

            Console.ReadKey();
        }
    }
}
