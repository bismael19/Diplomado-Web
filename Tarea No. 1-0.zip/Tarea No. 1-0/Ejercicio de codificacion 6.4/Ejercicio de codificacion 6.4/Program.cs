﻿using System;

namespace Ejercicio_de_codificacion_6._4
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Crear un programa que sume dos matrices, la matriz A y la matriz B.Imprimir la matriz resultante C.*/
            int[,] A = new int[2, 2];
            int[,] B = new int[2, 2];
            int[,] C = new int[2, 2];

            Console.WriteLine("Matriz A");
            for (int f = 0; f < 2; f++)
            {
                for (int c = 0; c < 2; c++)
                {
                    Console.Write($"Digite el valor de la coordenada {f}-{c}: ");
                    A[f, c] = int.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine("Matriz B");
            for (int f = 0; f < 2; f++)
            {
                for (int c = 0; c < 2; c++)
                {
                    Console.Write($"Digite el valor de la coordenada {f}-{c}: ");
                    B[f, c] = int.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine("Resultado Matriz C");
            for (int f = 0; f < 2; f++)
            {
                for (int c = 0; c < 2; c++)
                {
                    Console.Write("\n");
                    C[f, c] = A[f, c] + B[f, c];
                    Console.Write(C[f, c] + " ");
                }
            }
        }
    }
}
