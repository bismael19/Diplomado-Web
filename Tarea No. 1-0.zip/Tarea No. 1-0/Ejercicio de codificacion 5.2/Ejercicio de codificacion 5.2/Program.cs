﻿using System;

namespace Ejercicio_de_codificacion_5._2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Crear un menú de opciones usando do while que imprima la tabla de multiplicar deseada 
            por el usuario y calcule promedio.*/

            int NT = 0, RT = 0, CP = 0, VP = 0, RP = 0;
            string P = "";
            do
            {
                Console.WriteLine("********* MENU DE OPCIONES *********");
                Console.WriteLine("TABLA DE MULTIPLICAR [T]");
                Console.WriteLine("CALCULA PROMEDIO [P]");
                Console.WriteLine("SALIR [S]");
                Console.WriteLine("************************************");
                Console.Write("ESCRIBA UNA OPCION: {0}", P);

                P = Console.ReadLine();

                switch (P)
                {
                    case "t":
                    case "T":
                        Console.Write("Digite la tabla que desea imprimir: ");
                        NT = int.Parse(Console.ReadLine());
                        for (int i = 1; i <= 12; i++)
                        {
                            RT = NT * i;
                            Console.WriteLine(NT + " X " + i + " = " + RT);
                        }
                        break;
                    case "p":
                    case "P":
                        Console.Write("Digite la cantidad de valores a promediar: ");
                        CP = int.Parse(Console.ReadLine());
                        for (int i = 1; i <= CP; i++)
                        {
                            Console.Write($"Introduzca valor{i}: ");
                            VP = int.Parse(Console.ReadLine());
                            RP = RP + VP;
                        }
                        RP = RP / CP;
                        Console.WriteLine($"Su promedio es de: {RP}");
                        break;
                    default:
                        Console.WriteLine("Adios...");
                        break;
                }
            } while (P != "s" & P != "S");
        }
    }
}
