﻿using System;

namespace Ejercicio_de_codificacion_2._6
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Crear un programa en C# que calcule la cuota (c) de un préstamo simple. El monto (m) del
            préstamo, interés (i) y el tiempo(t) ingresaran por teclado.            Formula:
            c = ((m * i) / t) + (m / t)*/

            double c = 0, m = 0, i = 0;
            int t = 0;

            Console.WriteLine("Digite el monto del préstamo: ");            m = double.Parse(Console.ReadLine());            Console.WriteLine("Digite el interés: ");            i = double.Parse(Console.ReadLine());            Console.WriteLine("Digite el tiempo: ");            t = int.Parse(Console.ReadLine());

            c = ((m * i) / t) + (m / t);

            Console.WriteLine("Su cuota mensual es de: {0}", c);
        }
    }
}
