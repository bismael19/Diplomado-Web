﻿using System;

namespace Ejercicio_de_codificacion_2._2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Crear una aplicación en C# que calcule promedio de cuatro notas. Las variables a utilizar son nota
            enero, nota febrero, nota marzo, nota abril y promedio.*/

            Console.WriteLine("Digita la nota del mes de enero:");
            double nota_enero = double.Parse(Console.ReadLine());
            Console.WriteLine("Digita la nota del mes de febrero:");
            double nota_febrero = double.Parse(Console.ReadLine());
            Console.WriteLine("Digita la nota del mes de marzo:");
            double nota_marzo = double.Parse(Console.ReadLine());
            Console.WriteLine("Digita la nota del mes de abril:");
            double nota_abril = double.Parse(Console.ReadLine());

            double promedio = (nota_enero + nota_febrero + nota_marzo + nota_abril) / 4;

            Console.WriteLine("Su promedio es: {0}", promedio);

            Console.ReadKey();
        }
    }
}
