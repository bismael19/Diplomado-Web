﻿using System;

namespace Ejercicio_de_codificacion_3._2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa en C# que calcule el promedio de 4 notas tomando en cuenta el siguiente
            criterio para el resultado.*/

            int PN = 0, SN = 0, TN = 0, CN = 0, P = 0;
            string PT = null;

            Console.WriteLine("Digite la 1ra nota: ");
            PN = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite la 2da nota: ");
            SN = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite la 3ra nota: ");
            TN = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite la 4ta nota: ");
            CN = int.Parse(Console.ReadLine());

            P = (PN + SN + TN + CN) / 4;

            if ((P >= 0) && (P < 65))
            {
                PT = "¡Reprobado!";
            }
            else if ((P > 65) && (P < 75))
            {
                PT = "¡Aprobado!";
            }
            else if ((P > 75) && (P < 85))
            {
                PT = "¡Muy bueno!";
            }
            else if ((P > 85) && (P < 90))
            {
                PT = "¡Sobresaliente!";
            }
            else if ((P > 90) && (P <= 100))
            {
                PT = "¡Excelente!";
            }

            Console.WriteLine("{0} tienes {1} puntos en promedio...", PT, P);
            Console.ReadKey();
        }
    }
}
