﻿using System;

namespace Ejercicio_de_codificacion_4._3
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Un programa que muestre los números del 3 al 20 con su cubo al lado.*/

            double Cubo = 0;
            for (double Numero = 3; Numero <= 20; Numero++)            {
                Cubo = Math.Pow(Numero, 3);
                Console.WriteLine("El cubo de {0} es: {1}", Numero, Cubo);
            }            Console.ReadKey();
        }
    }
}
