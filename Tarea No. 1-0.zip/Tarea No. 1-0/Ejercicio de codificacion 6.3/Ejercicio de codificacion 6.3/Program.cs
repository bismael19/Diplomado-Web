﻿using System;

namespace Ejercicio_de_codificacion_6._3
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escriba un programa en C# que llene esta tabla con nombres de personas. La información se
            visualizará de la misma manera con dos bucles.*/

            string[,] tabla = new string[2,3];
            for (int f = 0; f < 2; f++)
            {
                for (int c = 0; c < 3; c++)
                {
                    Console.Write($"Digite el nombre de la posicion {f}-{c}: ");
                    tabla[f, c] = Console.ReadLine();
                    //Console.WriteLine(tabla[f, c] + " ");
                }
            }
            Console.WriteLine("");
            Console.WriteLine("*********** IMPRIMIENDO NOMBRES ***********");
            for (int fc = 0; fc < 2; fc++)
            {
                Console.WriteLine("");
                for (int cc = 0; cc < 3; cc++)
                {
                    Console.WriteLine(tabla[fc, cc] + " ");
                }
            }
            Console.ReadKey();
        }
    }
}
