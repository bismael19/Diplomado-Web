﻿using System;

namespace Ejercicio_de_codificacion_4._5
{
    class Program
    {
        static void Main(string[] args)
        {
            int R;
            for (int i = 1; i <= 12; i++)
            {
                Console.WriteLine();
                for (int j = 1; j <= 12; j++)
                {
                    R = j * i;
                    Console.WriteLine(i + " x " + j + " = " + R);
                }
            }
            Console.ReadLine();
        }
    }
}

