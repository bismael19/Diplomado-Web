﻿using System;

namespace Ejercicio_de_codificacion_5._1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Un programa que muestre la tabla de multiplicar del número 4.*/

            int N = 1, R = 0;
            while (N <= 12)
            {
                R = 4 * N;
                Console.WriteLine($"4 X {N} = {R}");
                N++;
            }
            Console.ReadKey();
        }
    }
}
