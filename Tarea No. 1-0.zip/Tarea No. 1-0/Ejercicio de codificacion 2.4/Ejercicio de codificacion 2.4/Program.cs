﻿using System;

namespace Ejercicio_de_codificacion_2._4
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Escribir un programa que C# que calcule sueldo bruto (SB), sueldo neto (SN) y descuento (DD). Las
            tarifas por horas(HT) y horas trabajadas(TH) ingresan por teclado.El descuento aplicar a todos los
            sueldos calculados es del 10 %.Imprimir sueldo bruto, descuento y sueldo neto.*/

            Console.WriteLine("Digite las tarifas por horas: ");
            double HT = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite las horas trabajadas: ");
            int TH = int.Parse(Console.ReadLine());

            double SB = HT * TH;
            double DD = SB * 0.1;
            double SN = SB - DD;

            Console.WriteLine("Su sueldo bruto es de: {0}", SB);
            Console.WriteLine("Tiene un descuento de: {0}", DD);
            Console.WriteLine("Su sueldo neto es de: {0}", SN);

        }
    }
}
