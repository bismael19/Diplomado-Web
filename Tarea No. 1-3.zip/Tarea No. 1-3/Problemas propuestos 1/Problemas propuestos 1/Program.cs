﻿using System;

namespace Problemas_propuestos_1
{
    class Program
    {
        double[] matutino = new double[4];
        double[] vespertino = new double[4];
        public void Cargar()
        {
            int N = 1;
            for (int f = 0; f < 4; f++)
            {
                Console.Write($"Digite sueldo del empleado{N} de la mañana: ");
                matutino[f] = double.Parse(Console.ReadLine());
                N++;
            }
            N = 1;
            for (int f = 0; f < 4; f++)
            {
                Console.Write($"Digite sueldo del empleado{N} de la tarde: ");
                vespertino[f] = double.Parse(Console.ReadLine());
                N++;
            }
        }
        public void Imprimir()
        {
            Console.WriteLine("Sueldos de empleados en la mañana");
            for (int f = 0; f < 4; f++)
            {
                Console.WriteLine(matutino[f]);
            }
            Console.WriteLine("Sueldos de empleados en la tarde");
            for (int f = 0; f < 4; f++)
            {
                Console.WriteLine(vespertino[f]);
            }
            Console.ReadKey();
        }
        static void Main(string[] args)
        {
            /*Una empresa tiene dos turnos(mañana y tarde) en los que trabajan 8 empleados(4 por
            la mañana y 4 por la tarde)
            Desarrollar un programa que permita almacenar los sueldos de los empleados agrupados
            por turno. Imprimir los gastos en sueldos de cada turno.*/
            Program mt = new Program();
            mt.Cargar();
            mt.Imprimir();
        }
    }
}
