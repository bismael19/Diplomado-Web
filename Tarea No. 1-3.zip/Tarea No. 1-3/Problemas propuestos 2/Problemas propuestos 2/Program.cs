﻿using System;

namespace Problemas_propuestos_2
{
    class Program
    {
        private int[,] mat = new int [3, 4];
        public void Cargar()
        {
            int N = 1;
            for (int f = 0; f < 3; f++)
            {
                for (int c = 0; c < 4; c++)
                {
                    Console.Write($"ingrese elemento{N}: ");
                    mat[f, c] = int.Parse(Console.ReadLine());
                    N++;
                }
            }
        }
        public void Imprimir()
        {
            for (int f = 0; f < 3; f++)
            {
                for (int c = 0; c < 4; c++)
                {
                    Console.Write(mat[f, c] + " ");
                }
                Console.WriteLine();
            }
        }
        public void ImprimirUltimaFila()
        {
            Console.WriteLine("Ultima fila");
            for (int c = 0; c < 4; c++)
            {
                Console.Write(mat[2, c] + " ");
            }
            Console.WriteLine();
        }
        public void ImprimirPrimeraFila()
        {
            Console.WriteLine("Primera fila");
            for (int c = 0; c < 4; c++)
            {
                Console.Write(mat[0, c] + " ");
            }
            Console.WriteLine();
        }
        public void ImprimirPrimeraColumna()
        {
            Console.WriteLine("Primera Columna");
            for (int f = 0; f < 3; f++)
            {
                Console.WriteLine(mat[f, 0]);
            }
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            /*Crear una matriz de 3 filas por 4 columnas e ingresar valores enteros, imprimir la primera
            fila. Imprimir la última fila e imprimir la primer columna*/
            Program ma = new Program();
            ma.Cargar();
            ma.Imprimir();
            ma.ImprimirPrimeraFila();
            ma.ImprimirUltimaFila();
            ma.ImprimirPrimeraColumna();
            Console.ReadKey();
        }
    }
}
