﻿using System;

namespace Ejercicio_1
{
    class Program
    {
        private int[,] mat;
        public void Cargar()
        {
            Console.Write("Cuantas filas tiene la matriz: ");
            string linea = Console.ReadLine();
            int filas = int.Parse(linea);
            Console.Write("Cuantas Columnas tiene la matriz: ");
            linea = Console.ReadLine();
            int columnas = int.Parse(linea);
            mat = new int[filas, columnas];
            for (int f = 0; f < mat.GetLength(0); f++)
            {
                for (int c = 0; c < mat.GetLength(1); c++)
                {
                    Console.Write("ingrese componente: ");
                    linea = Console.ReadLine();
                    mat[f, c] = int.Parse(linea);
                }
            }
        }
        public void Imprimir()
        {
            for (int f = 0; f < mat.GetLength(0); f++)
            {
                for (int c = 0; c < mat.GetLength(1); c++)
                {
                    Console.Write(mat[f, c] + " ");
                }
                Console.WriteLine();
            }
        }
        public void ImprimirUltimaFila()
        {
            Console.WriteLine("Ultima fila");
            for (int c = 0; c < mat.GetLength(1); c++)
            {
                Console.Write(mat[mat.GetLength(0) - 1, c] + " ");
            }
        }
        static void Main(string[] args)
        {
            /*Crear una matriz de n* m filas(cargar n y m por teclado) Imprimir la matriz completa
            y la última fila.*/
            Program ma = new Program();
            ma.Cargar();
            ma.Imprimir();
            ma.ImprimirUltimaFila();
            Console.ReadKey();
        }
    }
}
