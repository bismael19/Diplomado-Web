﻿using System;

namespace Ejercicio_2
{
    class Program
    {
        private double[] sueldo;
        public void Cargar()
        {
            int N = 1;
            sueldo = new double[5];
            for (int f = 0; f < 5; f++)
            {
                Console.Write($"Inserte el sueldo del operario{N}: ");
                sueldo[f] = double.Parse(Console.ReadLine());
                N++;
            }
        }
        public void Imprimir()
        {
            Console.WriteLine("Los 5 sueldos de los operarios");
            for (int f = 0; f < 5; f++)
            {
                Console.Write($"[{sueldo[f]}]");
            }
            Console.ReadLine();
        }
        static void Main(string[] args)
        {
            /*Realizar un programa que guardar los sueldos de 5 operarios en un arreglo de tipo vector*/
            Program su = new Program();
            su.Cargar();
            su.Imprimir();
        }
    }
}
